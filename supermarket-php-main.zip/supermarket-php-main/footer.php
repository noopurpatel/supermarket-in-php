
<div class="footer">
	Developed by Simiyu Benson Juma.
</div>
<?php
//close connection
if(isset($connect))
mysql_close();
?>

<!--body closes-->
</div>
</body>
</html>
